<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  
<?php

    
    require 'connexion_bdd.php';

    // Affiche 1 définition aléatoire de la base de données
    // $requete = $bdd->query("SELECT * FROM  `words`  ORDER BY ID ASC LIMIT 1");
    $requete = $bdd->query("SELECT * FROM  `words` ORDER BY rand() LIMIT 1");
    
    $definition = $requete->fetch();
    $bonne_reponse =  $definition['wordname'];
    echo '<p class="definition">'. $definition['definition'] .'</p>';
    

    $id = $definition['id'];
    
    // Affiche 3 mots aléatoires de la base de données
    $requete = $bdd->query("SELECT * FROM  `words` WHERE id != $id ORDER BY rand() ");
    
    for ($i= 0; $i < 3; $i++) {

      $donnees = $requete->fetch();
      $tableau[] = $donnees['wordname'];
      // echo($tableau[$i] ) .'<br />'  ;
      }
      array_push($tableau, $bonne_reponse);
      shuffle($tableau);
      foreach ($tableau as $reponse ) {

        echo '<span class="reponse">'. $reponse . '</span>';
      
      }

      // var_dump($tableau);
    ?>


</body>
</html>





